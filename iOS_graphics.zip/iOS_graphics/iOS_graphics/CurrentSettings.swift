//
//  CurrentSettings.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit
import Foundation

class CurrentSettings {
    static var width:CGFloat = 5
    static var color:ColorOption = ColorOption.all[0]
    
    static func getColor() -> UIColor {
        return ColorOption.getColor(color)
    }
}