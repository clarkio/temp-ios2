//
//  v_Settings.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit

class v_Settings: UIView {

    override func drawRect(rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        
        CGContextSetFillColorWithColor(context, CurrentSettings.getColor().CGColor)
        let rect = CGRect(x: 115, y: 20, width: 40, height: 40)
        
        CGContextFillRect(context, rect)
    }

}
