//
//  DrawingView.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/28/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit
import Foundation

class DrawingView:UIView {
    
    static var currentLine = Line(width: CurrentSettings.width, color: CurrentSettings.getColor())
    static var lines = [Line]()
    
    override func drawRect(rect:CGRect) {
        let context = UIGraphicsGetCurrentContext()
        
        if DrawingView.lines.count > 0 {
            for l in DrawingView.lines {
                l.draw(context)
            }
        }
        
        if DrawingView.currentLine.points.count > 0 {
            DrawingView.currentLine.width = CurrentSettings.width
            DrawingView.currentLine.color = CurrentSettings.getColor()
            DrawingView.currentLine.draw(context)
        }
    }
}