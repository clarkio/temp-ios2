//
//  Line.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit
import Foundation

class Line {
    var points = [DrawingPoint]()
    var width:CGFloat = 5
    var color:UIColor = UIColor.blackColor()
    
    init() {}
    
    init(width:CGFloat, color:UIColor) {
        self.width = width
        self.color = color
    }
    
    func draw(context:CGContext?) {
        let line = UIBezierPath()
        var setPoint = false
        
        CGContextSetStrokeColorWithColor(context, color.CGColor)
        line.lineWidth = width
        
        if points.count > 0 {
                for p in points {
                    if !setPoint {
                        line.moveToPoint(p.getCGPoint())
                        setPoint = true
                    } else {
                        line.addLineToPoint(p.getCGPoint())
                    }
                }
                
                line.stroke()
        }
    }
}