//
//  ColorOption.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit
import Foundation

enum ColorOption {
    case Black, Red, Green, Blue, Purple
    
    static let all = [Black, Red, Green, Blue, Purple]
    
    static func getColor(option:ColorOption) -> UIColor {
        switch option {
        case Red:
            return UIColor.redColor()
        case Green:
            return UIColor.greenColor()
        case Blue:
            return UIColor.blueColor()
        case Purple:
            return UIColor.purpleColor()
        case Black:
            return UIColor.blackColor()
        }
    }
}