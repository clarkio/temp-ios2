//
//  vc_Settings.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit

class vc_Settings: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet var widthTextField:UITextField!
    @IBOutlet var colorPicker:UIPickerView!
    @IBOutlet var settingsView:UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let text = widthTextField.text {
            let numericWidth = Int(text)
            if let numericWidth = numericWidth {
                CurrentSettings.width = CGFloat(numericWidth)
            }
            else {
                widthTextField.text = "5"
                CurrentSettings.width = 5
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(ColorOption.all[row])
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return ColorOption.all.count
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        CurrentSettings.color = ColorOption.all[row]
        settingsView.setNeedsDisplay()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
