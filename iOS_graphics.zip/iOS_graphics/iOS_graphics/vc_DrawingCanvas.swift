//
//  vc_DrawingCanvas.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import UIKit

class vc_DrawingCanvas: UIViewController {

    var allowDraw = true
    
    @IBOutlet var drawingView:DrawingView!
    
    @IBAction func clearCanvas(sender:UIButton) {
        DrawingView.currentLine = Line(width: CurrentSettings.width, color: CurrentSettings.getColor())
        DrawingView.lines = [Line]()
        drawingView.setNeedsDisplay()
    }
    
    @IBAction func flipSwitch(sender:UISwitch) {
        allowDraw = sender.on
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        drawingView.addGestureRecognizer(pan)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func handlePanGesture (sender:UIPanGestureRecognizer) {
        if allowDraw {
            let point = DrawingPoint(x: sender.locationInView(drawingView).x, y: sender.locationInView(drawingView).y)
            DrawingView.currentLine.points.append(point)
            
            if sender.state == .Ended {
                if DrawingView.currentLine.points.count > 0 {
                    DrawingView.lines.append(DrawingView.currentLine)
                    DrawingView.currentLine = Line(width: CurrentSettings.width, color: CurrentSettings.getColor())
                }
            }
        
            drawingView.setNeedsDisplay()
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
