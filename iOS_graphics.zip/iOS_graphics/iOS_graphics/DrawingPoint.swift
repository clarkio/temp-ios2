//
//  DrawingPoint.swift
//  iOS_graphics
//
//  Created by Dale, Pam on 7/29/16.
//  Copyright © 2016 Disney. All rights reserved.
//

import Foundation
import UIKit

class DrawingPoint {
    let x:CGFloat
    let y:CGFloat
    
    init (x:CGFloat, y:CGFloat) {
        self.x = x
        self.y = y
    }
    
    func getCGPoint() -> CGPoint {
        return CGPoint(x:x, y:y)
    }
}